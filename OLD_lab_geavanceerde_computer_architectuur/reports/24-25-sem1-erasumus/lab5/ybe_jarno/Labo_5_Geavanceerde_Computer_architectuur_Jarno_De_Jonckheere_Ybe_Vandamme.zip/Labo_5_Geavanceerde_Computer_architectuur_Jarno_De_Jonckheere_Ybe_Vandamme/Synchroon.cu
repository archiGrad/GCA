#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <stdlib.h>
#include <stdio.h>
#include <cuda.h>



__global__ void vectorMaxReduction (int *A,int *output,int numElements) {
    extern __shared__ int shared_data[];

    int tid = threadIdx.x;
    int idx = blockIdx.x * blockDim.x + threadIdx.x;

    if(idx<numElements){
        shared_data[tid] = A[idx];
    } else{
        shared_data[tid] = 0;
    }
    __syncthreads();

    for(int step = blockDim.x/2; step >0; step /=2){
        if(tid < step){
            shared_data[tid] = max(shared_data[tid], shared_data[tid+step]);
        }
    }
    __syncthreads();
    if(tid == 0){
        output[blockIdx.x] = shared_data[0];
    }
}


__global__ void vectorSumReduction (int *A,int *output,int numElements) {
    extern __shared__ int shared_data[];

    int tid = threadIdx.x;
    int idx = blockIdx.x * blockDim.x + threadIdx.x;

    if(idx<numElements){
        shared_data[tid] = A[idx];
    } else{
        shared_data[tid] = 0;
    }
    __syncthreads();

    for(int step = blockDim.x/2; step >0; step /=2){
        if(tid < step ){
            shared_data[tid] = shared_data[tid] + shared_data[tid+step];
        }
       
    }
     __syncthreads();
    if(tid == 0){
        output[blockIdx.x] = shared_data[0];
    }
}


__global__ void vectorProdReduction (int *A,int *output,int numElements) {
    extern __shared__ int shared_data[];

    int tid = threadIdx.x;
    int idx = blockIdx.x * blockDim.x + threadIdx.x;

    if(idx<numElements){
        shared_data[tid] = A[idx];
    } else{
        shared_data[tid] = 1;
    }
    __syncthreads();

    for(int step = blockDim.x/2; step >0; step /=2){
        if(tid < step){
            shared_data[tid] = shared_data[tid] * shared_data[tid+step];
        }
    }
    __syncthreads();
    if(tid == 0){
        output[blockIdx.x] = shared_data[0];
    }
}

__global__ void vectorMinReduction (int *A,int *output,int numElements) {
    extern __shared__ int shared_data[];

    int tid = threadIdx.x;
    int idx = blockIdx.x * blockDim.x + threadIdx.x;

    if(idx<numElements){
        shared_data[tid] = A[idx];
    } else{
        shared_data[tid] = INT_MAX;
    }
    __syncthreads();

    for(int step = blockDim.x/2; step >0; step /=2){
        if(tid < step){
            shared_data[tid] = min(shared_data[tid] , shared_data[tid+step]);
        }
        __syncthreads(); 
    }
    
    if(tid == 0){
        output[blockIdx.x] = shared_data[0];
    }
}


int maxReduction(int* h_array,int size){
    int *d_input, *d_output;
    int threads = 8;
    int blocks = (size + threads - 1) / threads;
    cudaMalloc((void **)&d_input, size * sizeof(int));
    cudaMalloc((void **)&d_output, blocks * sizeof(int));
    
    cudaMemcpy(d_input, h_array, size * sizeof(int), cudaMemcpyHostToDevice); 
    clock_t begin = clock();
    vectorMaxReduction<<<blocks, threads, threads*sizeof(int)>>>(d_input,d_output,size);
    int *h_output = new int[blocks];
    cudaMemcpy(h_output, d_output,blocks*sizeof(int),cudaMemcpyDeviceToHost);
    int max_val = h_output[0];
    for(int i = 1; i<blocks;i++){
        max_val = max(max_val, h_output[i]);
    }
    clock_t end = clock();
    double time = (double) (end-begin) / CLOCKS_PER_SEC;
    printf("GPU reduction TIJD; %f ; ", time);

    cudaFree(d_input);
    cudaFree(d_output);
    delete[] h_output;
    
    return max_val;
}

int sumReduction(int* h_array,int size){
    int *d_input, *d_output;
    int threads = 8;
    int blocks = (size + threads - 1) / threads;
    cudaMalloc((void **)&d_input, size * sizeof(int));
    cudaMalloc((void **)&d_output, blocks * sizeof(int));
    
    cudaMemcpy(d_input, h_array, size * sizeof(int), cudaMemcpyHostToDevice); 
    clock_t begin = clock();
    vectorSumReduction<<<blocks, threads, threads*sizeof(int)>>>(d_input,d_output,size);
    int *h_output = new int[blocks];
    cudaMemcpy(h_output, d_output,blocks*sizeof(int),cudaMemcpyDeviceToHost);
    int max_val = h_output[0];
    for(int i = 1; i<blocks;i++){
        max_val = max_val + h_output[i];
    }
    clock_t end = clock();
    double time = (double) (end-begin) / CLOCKS_PER_SEC;
    printf("GPU reduction TIJD; %f ; ", time);

    cudaFree(d_input);
    cudaFree(d_output);
    delete[] h_output;
    
    return max_val;
}

int minReduction(int* h_array,int size){
    int *d_input, *d_output;
    int threads = 8;
    int blocks = (size + threads - 1) / threads;
    cudaMalloc((void **)&d_input, size * sizeof(int));
    cudaMalloc((void **)&d_output, blocks * sizeof(int));
    
    cudaMemcpy(d_input, h_array, size * sizeof(int), cudaMemcpyHostToDevice); 
    clock_t begin = clock();
    vectorMinReduction<<<blocks, threads, threads*sizeof(int)>>>(d_input,d_output,size);
    int *h_output = new int[blocks];
    cudaMemcpy(h_output, d_output,blocks*sizeof(int),cudaMemcpyDeviceToHost);
    int max_val = h_output[0];
    for(int i = 1; i<blocks;i++){
        max_val = min(max_val, h_output[i]);
    }
    clock_t end = clock();
    double time = (double) (end-begin) / CLOCKS_PER_SEC;
    printf("GPU reduction TIJD; %f ; ", time);

    cudaFree(d_input);
    cudaFree(d_output);
    delete[] h_output;
    
    return max_val;
}


int prodReduction(int* h_array,int size){
    int *d_input, *d_output;
    int threads = 8;
    int blocks = (size + threads - 1) / threads;
    cudaMalloc((void **)&d_input, size * sizeof(int));
    cudaMalloc((void **)&d_output, blocks * sizeof(int));
    
    cudaMemcpy(d_input, h_array, size * sizeof(int), cudaMemcpyHostToDevice); 
    clock_t begin = clock();
    vectorProdReduction<<<blocks, threads, threads*sizeof(int)>>>(d_input,d_output,size);
    int *h_output = new int[blocks];
    cudaMemcpy(h_output, d_output,blocks*sizeof(int),cudaMemcpyDeviceToHost);
    int max_val = h_output[0];
    for(int i = 1; i<blocks;i++){
        max_val = max_val * h_output[i];
    }
    clock_t end = clock();
    double time = (double) (end-begin) / CLOCKS_PER_SEC;
    printf("GPU reduction TIJD; %f ; ", time);

    cudaFree(d_input);
    cudaFree(d_output);
    delete[] h_output;
    
    return max_val;
}






int main() {
    for(int j = 10;j<10000;j=j+50){
        printf("array-size ;%d;",j);
        clock_t begin = clock();
        int h_array[j];
        int q_array[j];
        int f_array[j];
        int a_array[j];
        printf("h_ array[ ");
        for (int i=0; i<j; i++){
            h_array[i]= rand()%100;
            printf("%d ",h_array[i]);
        }
        printf("]\n");


        int size = sizeof(h_array) / sizeof(h_array[0]);

        //max by reduction
        int maxR = maxReduction(h_array,size);
        printf("maxReduction; %d ; \n",maxR);

        printf("q_ array[ ");
        for (int i=0; i<j; i++){
            q_array[i]= rand()%100;
            printf("%d ",q_array[i]);
        }
        printf("]\n");

        //sum by reduction
        int sumR = sumReduction(q_array,size);
        printf("sumReduction; %d ; \n",sumR);

        printf("f_ array[ ");
        for (int i=0; i<j; i++){
            f_array[i]= rand()%10+1;
            printf("%d ",f_array[i]);
        }
        printf("]\n");

        //product by reduction
        int prodR = prodReduction(f_array,size);
        printf("productReduction; %d ; \n",prodR);

        printf("a_ array[ ");
        for (int i=0; i<j; i++){
            a_array[i]= rand()%100;
            printf("%d ",a_array[i]);
        }
        printf("]\n");


        //min by reduction
        int minR = minReduction(a_array,size);
        printf("minReduction; %d ; \n",minR);
        clock_t end = clock();
        double time = (double) (end-begin) / CLOCKS_PER_SEC;
        printf("time; %f ; \n", time);

    }
    
return 0;
}
