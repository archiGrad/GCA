#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <stdlib.h>
#include <stdio.h>
#include <cuda.h>



__global__ void vectorMaxReduction (int *A,int *output,int numElements) {
    extern __shared__ int shared_data[];

    int tid = threadIdx.x;
    int idx = blockIdx.x * blockDim.x + threadIdx.x;

    if(idx<numElements){
        shared_data[tid] = A[idx];
    } else{
        shared_data[tid] = 0;
    }
    __syncthreads();

    for(int step = blockDim.x/2; step >0; step /=2){
        if(tid < step){
            shared_data[tid] = max(shared_data[tid], shared_data[tid+step]);
        }
    }
    __syncthreads();
    if(tid == 0){
        output[blockIdx.x] = shared_data[0];
    }
}


__global__ void vectorSumReduction (int *A,int *output,int numElements) {
    extern __shared__ int shared_data[];

    int tid = threadIdx.x;
    int idx = blockIdx.x * blockDim.x + threadIdx.x;

    if(idx<numElements){
        shared_data[tid] = A[idx];
    } else{
        shared_data[tid] = 0;
    }
    __syncthreads();

    for(int step = blockDim.x/2; step >0; step /=2){
        if(tid < step ){
            shared_data[tid] = shared_data[tid] + shared_data[tid+step];
        }
       
    }
     __syncthreads();
    if(tid == 0){
        output[blockIdx.x] = shared_data[0];
    }
}


__global__ void vectorProdReduction (int *A,int *output,int numElements) {
    extern __shared__ int shared_data[];

    int tid = threadIdx.x;
    int idx = blockIdx.x * blockDim.x + threadIdx.x;

    if(idx<numElements){
        shared_data[tid] = A[idx];
    } else{
        shared_data[tid] = 1;
    }
    __syncthreads();

    for(int step = blockDim.x/2; step >0; step /=2){
        if(tid < step){
            shared_data[tid] = shared_data[tid] * shared_data[tid+step];
        }
    }
    __syncthreads();
    if(tid == 0){
        output[blockIdx.x] = shared_data[0];
    }
}

__global__ void vectorMinReduction (int *A,int *output,int numElements) {
    extern __shared__ int shared_data[];

    int tid = threadIdx.x;
    int idx = blockIdx.x * blockDim.x + threadIdx.x;

    if(idx<numElements){
        shared_data[tid] = A[idx];
    } else{
        shared_data[tid] = INT_MAX;
    }
    __syncthreads();

    for(int step = blockDim.x/2; step >0; step /=2){
        if(tid < step){
            shared_data[tid] = min(shared_data[tid] , shared_data[tid+step]);
        }
        __syncthreads(); 
    }
    
    if(tid == 0){
        output[blockIdx.x] = shared_data[0];
    }
}

void asynchronous(int *h_array,int *q_array, int* f_array,int *a_array,int size){
    int *d_input, *d_output;
    int *d1_input, *d1_output;
    int *d2_input, *d2_output;
    int *d3_input, *d3_output;

    int threads = 8;
    int blocks = (size + threads - 1) / threads;

    cudaStream_t stream1;
    cudaStream_t stream2;
    cudaStream_t stream3;
    cudaStream_t stream4;

    cudaStreamCreate(&stream1);
    cudaStreamCreate(&stream2);
    cudaStreamCreate(&stream3);
    cudaStreamCreate(&stream4);


    cudaMalloc((void **)&d_input, size * sizeof(int));
    cudaMalloc((void **)&d_output, blocks * sizeof(int));
    cudaMalloc((void **)&d1_input, size * sizeof(int));
    cudaMalloc((void **)&d1_output, blocks * sizeof(int));
    cudaMalloc((void **)&d2_input, size * sizeof(int));
    cudaMalloc((void **)&d2_output, blocks * sizeof(int));
    cudaMalloc((void **)&d3_input, size * sizeof(int));
    cudaMalloc((void **)&d3_output, blocks * sizeof(int));

    cudaMemcpyAsync(d_input, h_array, size * sizeof(int), cudaMemcpyHostToDevice,stream1); 
    cudaMemcpyAsync(d1_input, q_array, size * sizeof(int), cudaMemcpyHostToDevice,stream2);
    cudaMemcpyAsync(d2_input, f_array, size * sizeof(int), cudaMemcpyHostToDevice,stream2);
    cudaMemcpyAsync(d3_input, a_array, size * sizeof(int), cudaMemcpyHostToDevice,stream3);

    vectorMaxReduction<<<blocks, threads, threads*sizeof(int),stream1>>>(d_input,d_output,size);
    vectorSumReduction<<<blocks, threads, threads*sizeof(int),stream2>>>(d1_input,d1_output,size);
    vectorProdReduction<<<blocks, threads, threads*sizeof(int),stream3>>>(d2_input,d2_output,size);
    vectorMinReduction<<<blocks, threads, threads*sizeof(int),stream4>>>(d3_input,d3_output,size);

    int *h1_output = new int[blocks];
    int *h2_output = new int[blocks];
    int *h3_output = new int[blocks];
    int *h4_output = new int[blocks];

    cudaMemcpyAsync(h1_output, d_output,blocks*sizeof(int),cudaMemcpyDeviceToHost,stream1);
    cudaMemcpyAsync(h2_output, d1_output,blocks*sizeof(int),cudaMemcpyDeviceToHost,stream2);
    cudaMemcpyAsync(h3_output, d2_output,blocks*sizeof(int),cudaMemcpyDeviceToHost,stream3);
    cudaMemcpyAsync(h4_output, d3_output,blocks*sizeof(int),cudaMemcpyDeviceToHost,stream4);

    cudaStreamSynchronize(stream1);
    cudaStreamSynchronize(stream2);
    cudaStreamSynchronize(stream3);
    cudaStreamSynchronize(stream4);


    int max_val = h1_output[0];
    for(int i = 1; i<blocks;i++){
        max_val = max(max_val, h1_output[i]);
    }
    int sum_val = h2_output[0];
    for(int i = 1; i<blocks;i++){
        sum_val = sum_val + h2_output[i];
    }
    int min_val = h4_output[0];
    for(int i = 1; i<blocks;i++){
        min_val = min(min_val, h4_output[i]);
    }
    int prod_val = h3_output[0];
    for(int i = 1; i<blocks;i++){
        prod_val = prod_val * h3_output[i];
    }


    cudaFree(d_input);
    cudaFree(d_output);
    delete[] h1_output;


    cudaFree(d1_input);
    cudaFree(d1_output);
    delete[] h2_output;

    cudaFree(d2_input);
    cudaFree(d2_output);
    delete[] h3_output;

    cudaFree(d3_input);
    cudaFree(d3_output);
    delete[] h4_output;


    cudaStreamDestroy(stream1);
    cudaStreamDestroy(stream2);
    cudaStreamDestroy(stream3);
    cudaStreamDestroy(stream4);

    printf("\n max: %d\n",max_val);
    printf("\n sum: %d\n",sum_val);
    printf("\n prod: %d\n",prod_val);
    printf("\n min: %d\n",min_val);
    
    
}


int maxReduction(int* h_array,int size){
    int *d_input, *d_output;
    int threads = 8;
    int blocks = (size + threads - 1) / threads;
    cudaMalloc((void **)&d_input, size * sizeof(int));
    cudaMalloc((void **)&d_output, blocks * sizeof(int));
    
    cudaMemcpy(d_input, h_array, size * sizeof(int), cudaMemcpyHostToDevice); 
    //clock_t begin = clock();
    vectorMaxReduction<<<blocks, threads, threads*sizeof(int)>>>(d_input,d_output,size);
    int *h_output = new int[blocks];
    cudaMemcpy(h_output, d_output,blocks*sizeof(int),cudaMemcpyDeviceToHost);
    int max_val = h_output[0];
    for(int i = 1; i<blocks;i++){
        max_val = max(max_val, h_output[i]);
    }
    //clock_t end = clock();
    //double time = (double) (end-begin) / CLOCKS_PER_SEC;
    //printf("GPU reduction TIJD; %f ; ", time);

    cudaFree(d_input);
    cudaFree(d_output);
    delete[] h_output;
    
    return max_val;
}

int sumReduction(int* h_array,int size){
    int *d_input, *d_output;
    int threads = 8;
    int blocks = (size + threads - 1) / threads;
    cudaMalloc((void **)&d_input, size * sizeof(int));
    cudaMalloc((void **)&d_output, blocks * sizeof(int));
    
    cudaMemcpy(d_input, h_array, size * sizeof(int), cudaMemcpyHostToDevice); 
    //clock_t begin = clock();
    vectorSumReduction<<<blocks, threads, threads*sizeof(int)>>>(d_input,d_output,size);
    int *h_output = new int[blocks];
    cudaMemcpy(h_output, d_output,blocks*sizeof(int),cudaMemcpyDeviceToHost);
    int max_val = h_output[0];
    for(int i = 1; i<blocks;i++){
        max_val = max_val + h_output[i];
    }
    //clock_t end = clock();
    //double time = (double) (end-begin) / CLOCKS_PER_SEC;
    //printf("GPU reduction TIJD; %f ; ", time);

    cudaFree(d_input);
    cudaFree(d_output);
    delete[] h_output;
    
    return max_val;
}






int minReduction(int* h_array,int size){
    int *d_input, *d_output;
    int threads = 8;
    int blocks = (size + threads - 1) / threads;
    cudaMalloc((void **)&d_input, size * sizeof(int));
    cudaMalloc((void **)&d_output, blocks * sizeof(int));
    
    cudaMemcpy(d_input, h_array, size * sizeof(int), cudaMemcpyHostToDevice); 
    //clock_t begin = clock();
    vectorMinReduction<<<blocks, threads, threads*sizeof(int)>>>(d_input,d_output,size);
    int *h_output = new int[blocks];
    cudaMemcpy(h_output, d_output,blocks*sizeof(int),cudaMemcpyDeviceToHost);
    int max_val = h_output[0];
    for(int i = 1; i<blocks;i++){
        max_val = min(max_val, h_output[i]);
    }
    //clock_t end = clock();
    //double time = (double) (end-begin) / CLOCKS_PER_SEC;
    //printf("GPU reduction TIJD; %f ; ", time);

    cudaFree(d_input);
    cudaFree(d_output);
    delete[] h_output;
    
    return max_val;
}


int prodReduction(int* h_array,int size){
    int *d_input, *d_output;
    int threads = 8;
    int blocks = (size + threads - 1) / threads;
    cudaMalloc((void **)&d_input, size * sizeof(int));
    cudaMalloc((void **)&d_output, blocks * sizeof(int));
    
    cudaMemcpy(d_input, h_array, size * sizeof(int), cudaMemcpyHostToDevice); 
    //clock_t begin = clock();
    vectorProdReduction<<<blocks, threads, threads*sizeof(int)>>>(d_input,d_output,size);
    int *h_output = new int[blocks];
    cudaMemcpy(h_output, d_output,blocks*sizeof(int),cudaMemcpyDeviceToHost);
    int max_val = h_output[0];
    for(int i = 1; i<blocks;i++){
        max_val = max_val * h_output[i];
    }
    //clock_t end = clock();
    //double time = (double) (end-begin) / CLOCKS_PER_SEC;
    ////printf("GPU reduction TIJD; %f ; ", time);

    cudaFree(d_input);
    cudaFree(d_output);
    delete[] h_output;
    
    return max_val;
}





int main() {
    for(int j = 10;j<10000;j=j+10){
        int threads = 50;
        printf("array-size ; %d;",j);
        clock_t begin = clock();
        int h_array[j];
        int q_array[j];
        int f_array[j];
        int a_array[j];
        //printf("h_ array[ ");
        for (int i=0; i<j; i++){
            h_array[i]= rand()%100;
            //printf("%d ",h_array[i]);
        }
        //printf("]\n");


        int size = sizeof(h_array) / sizeof(h_array[0]);
        int blocks = (size + threads - 1) / threads;
        //max by reduction
        //int maxR = maxReduction(h_array,size);
        //printf("maxReduction; %d ; \n",maxR);

        //asynchronous max
        int *d_input, *d_output;
        cudaStream_t stream1;
        cudaStreamCreate(&stream1);
        cudaMalloc((void **)&d_input, size * sizeof(int));
        cudaMalloc((void **)&d_output, blocks * sizeof(int));
        cudaMemcpyAsync(d_input, h_array, size * sizeof(int), cudaMemcpyHostToDevice,stream1); 
        vectorMaxReduction<<<blocks, threads, threads*sizeof(int),stream1>>>(d_input,d_output,size);
        int *h1_output = new int[blocks];
        

        //printf("q_ array[ ");
        for (int i=0; i<j; i++){
            q_array[i]= rand()%100;
            //printf("%d ",q_array[i]);
        }
        //printf("]\n");

        //int sumR = sumReduction(q_array,size);
        //printf("sumReduction; %d ; \n",sumR);

        //asynchronous sum
        int *d1_input, *d1_output;
        cudaStream_t stream2;
        cudaStreamCreate(&stream2);
        cudaMalloc((void **)&d1_input, size * sizeof(int));
        cudaMalloc((void **)&d1_output, blocks * sizeof(int));
        cudaMemcpyAsync(d1_input, q_array, size * sizeof(int), cudaMemcpyHostToDevice,stream2);
        vectorSumReduction<<<blocks, threads, threads*sizeof(int),stream2>>>(d1_input,d1_output,size);
        int *h2_output = new int[blocks];
        

        // printf("f_ array[ ");
        for (int i=0; i<j; i++){
            f_array[i]= rand()%10+1;
        // printf("%d ",f_array[i]);
        }
        //printf("]\n");

        
        //int prodR = prodReduction(f_array,size);
        //printf("productReduction; %d ; \n",prodR);

        //asynchronous prod
        int *d2_input, *d2_output;
        cudaStream_t stream3;
        cudaStreamCreate(&stream3);
        cudaMalloc((void **)&d2_input, size * sizeof(int));
        cudaMalloc((void **)&d2_output, blocks * sizeof(int));
        cudaMemcpyAsync(d2_input, f_array, size * sizeof(int), cudaMemcpyHostToDevice,stream2);
        vectorProdReduction<<<blocks, threads, threads*sizeof(int),stream3>>>(d2_input,d2_output,size);
        int *h3_output = new int[blocks];
        

        //printf("a_ array[ ");
        for (int i=0; i<j; i++){
            a_array[i]= rand()%100;
            //printf("%d ",a_array[i]);
        }
        //printf("]\n");



        //int minR = minReduction(a_array,size);
        //printf("minReduction; %d ; \n",minR);

        //asynchronous min
        int *d3_input, *d3_output;
        cudaStream_t stream4;
        cudaStreamCreate(&stream4);
        cudaMalloc((void **)&d3_input, size * sizeof(int));
        cudaMalloc((void **)&d3_output, blocks * sizeof(int));
        cudaMemcpyAsync(d3_input, a_array, size * sizeof(int), cudaMemcpyHostToDevice,stream4);
        vectorMinReduction<<<blocks, threads, threads*sizeof(int),stream4>>>(d3_input,d3_output,size);
        int *h4_output = new int[blocks];
        
        
        cudaMemcpyAsync(h1_output, d_output,blocks*sizeof(int),cudaMemcpyDeviceToHost,stream1);
        cudaStreamSynchronize(stream1);
        int max_val = h1_output[0];
        for(int i = 1; i<blocks;i++){
            max_val = max(max_val, h1_output[i]);
        }

        
    
        cudaMemcpyAsync(h2_output, d1_output,blocks*sizeof(int),cudaMemcpyDeviceToHost,stream2);
        cudaStreamSynchronize(stream2);
        int sum_val = h2_output[0];
        for(int i = 1; i<blocks;i++){
            sum_val = sum_val + h2_output[i];
        }
    

        
        cudaMemcpyAsync(h3_output, d2_output,blocks*sizeof(int),cudaMemcpyDeviceToHost,stream3);
        cudaStreamSynchronize(stream3);
        int prod_val = h3_output[0];
        for(int i = 1; i<blocks;i++){
            prod_val = prod_val * h3_output[i];
        }

        

        
        
        cudaMemcpyAsync(h4_output, d3_output,blocks*sizeof(int),cudaMemcpyDeviceToHost,stream4);
        cudaStreamSynchronize(stream4);
        int min_val = h4_output[0];
        for(int i = 1; i<blocks;i++){
            min_val = min(min_val, h4_output[i]);
        }

        
        cudaFree(d_input);
        cudaFree(d_output);
        delete[] h1_output;
        cudaFree(d1_input);
        cudaFree(d1_output);
        delete[] h2_output;
        cudaFree(d2_input);
        cudaFree(d2_output);
        delete[] h3_output;
        cudaFree(d3_input);
        cudaFree(d3_output);
        delete[] h4_output;

        cudaStreamDestroy(stream1);
        cudaStreamDestroy(stream2);
        cudaStreamDestroy(stream3);
        cudaStreamDestroy(stream4);

        //printf("\n max: %d\n",max_val);
        //printf("\n sum: %d\n",sum_val);
        //printf("\n prod: %d\n",prod_val);
        //printf("\n min: %d\n",min_val);
        

        clock_t end = clock();
        double time = (double) (end-begin) / CLOCKS_PER_SEC;
        printf("time; %f ; \n", time);
        
        //initial testing function for comparison
        //asynchronous(h_array,q_array,f_array,a_array,size);

    }
return 0;
}
